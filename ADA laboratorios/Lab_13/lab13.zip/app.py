#Importando el OPenCV
import numpy as np
from sys import maxsize
import cv2

def adyacenteIzq(dimension, posI, posJ):
    if posJ == 0:
        return [0, 0]
    else:
        return [posI, posJ-1]

def adyacenteInf(dimension, posI, posJ):
    if posI == dimension[0]-1:
        return [0, 0]
    else:
        return [posI+1, posJ]

def adyacenteDer(dimension, posI, posJ):
    if posI == dimension[0]-1 or posJ == dimension[1]-1:
        return [0, 0]
    else:
        return [posI+1, posJ+1]

def energy(imagen, axisX, axisY):    
    (Bx1, Gx1, Rx1) = imagen[axisX+1, axisY]
    (Bx2, Gx2, Rx2) = imagen[axisX-1, axisY]
    Bx = abs(int(Bx1) - int(Bx2))
    Gx = abs(int(Gx1) - int(Gx2))
    Rx = abs(int(Rx1) - int(Rx2))
    (By1, Gy1, Ry1) = imagen[axisX, axisY+1]
    (By2, Gy2, Ry2) = imagen[axisX, axisY-1]
    By = abs(int(By1) - int(By2))
    Gy = abs(int(Gy1) - int(Gy2))
    Ry = abs(int(Ry1) - int(Ry2))
    
    Bx = pow(Bx, 2)
    Gx = pow(Gx, 2)
    Rx = pow(Rx, 2)
    By = pow(By, 2)
    Gy = pow(Gy, 2)
    Ry = pow(Ry, 2)
    squareGradientX = Bx + Gx + Rx
    squareGradientY = By + Gy + Ry
    pixelEnergy = round((np.sqrt(squareGradientX + squareGradientY)), 3)
    return pixelEnergy

def getEnergyMatrix(imagen, dimension):
    energyMatrix = np.zeros((dimension[0], dimension[1]))
    for i in range(1, dimension[0]-1):
        for j in range(1, dimension[1]-1):
            energyMatrix[i, j] = energy(imagen, i, j)
    for i in range(0, dimension[0]):
        energyMatrix[i, 0] = 1000
        energyMatrix[i, dimension[1]-1] = 1000
    for j in range(0, dimension[1]):
        energyMatrix[0, j] = 1000
        energyMatrix[dimension[0]-1, j] = 1000
    return energyMatrix

def getVerticalSeam(imagen, dimension):
    energyMatrix = getEnergyMatrix(imagen, dimension)
    verticalSeam = np.zeros((dimension[0], dimension[1]))
    for i in range(0, dimension[0]):
        verticalSeam[i, 0] = energyMatrix[i, 0]
    for j in range(1, dimension[1]):
        for i in range(0, dimension[0]):
            if i == 0:
                verticalSeam[i, j] = energyMatrix[i, j] + min(verticalSeam[i, j-1], verticalSeam[i+1, j-1])
            elif i == dimension[0]-1:
                verticalSeam[i, j] = energyMatrix[i, j] + min(verticalSeam[i-1, j-1], verticalSeam[i, j-1])
            else:
                verticalSeam[i, j] = energyMatrix[i, j] + min(verticalSeam[i-1, j-1], verticalSeam[i, j-1], verticalSeam[i+1, j-1])
    return verticalSeam

def getHorizontalSeam(imagen, dimension):
    energyMatrix = getEnergyMatrix(imagen)
    horizontalSeam = np.zeros((dimension[0], dimension[1]))
    for j in range(0, dimension[1]):
        horizontalSeam[0, j] = energyMatrix[0, j]
    for i in range(1, dimension[0]):
        for j in range(0, dimension[1]):
            if j == 0:
                horizontalSeam[i, j] = energyMatrix[i, j] + min(horizontalSeam[i-1, j], horizontalSeam[i-1, j+1])
            elif j == dimension[1]-1:
                horizontalSeam[i, j] = energyMatrix[i, j] + min(horizontalSeam[i-1, j-1], horizontalSeam[i-1, j])
            else:
                horizontalSeam[i, j] = energyMatrix[i, j] + min(horizontalSeam[i-1, j-1], horizontalSeam[i-1, j], horizontalSeam[i-1, j+1])
    return horizontalSeam

def getVerticalSeamPath(imagen, dimension):
    verticalSeam = getVerticalSeam(imagen, dimension)
    verticalSeamPath = np.zeros((dimension[0], dimension[1]))
    minimo = maxsize
    for i in range(0, dimension[0]):
        if verticalSeam[i, dimension[1]-1] < minimo:
            minimo = verticalSeam[i, dimension[1]-1]
            verticalSeamPath[i, dimension[1]-1] = 1
    for j in range(dimension[1]-2, 0, -1):
        for i in range(0, dimension[0]):
            if i == 0:
                if verticalSeam[i, j] + min(verticalSeam[i, j+1], verticalSeam[i+1, j+1]) == minimo:
                    verticalSeamPath[i, j] = 1
                    minimo = verticalSeam[i, j]
            elif i == dimension[0]-1:
                if verticalSeam[i, j] + min(verticalSeam[i-1, j+1], verticalSeam[i, j+1]) == minimo:
                    verticalSeamPath[i, j] = 1
                    minimo = verticalSeam[i, j]
            else:
                if verticalSeam[i, j] + min(verticalSeam[i-1, j+1], verticalSeam[i, j+1], verticalSeam[i+1, j+1]) == minimo:
                    verticalSeamPath[i, j] = 1
                    minimo = verticalSeam[i, j]
    return verticalSeamPath

def getHorizontalSeamPath(imagen, dimension):
    horizontalSeam = getHorizontalSeam(imagen)
    horizontalSeamPath = np.zeros((dimension[0], dimension[1]))
    minimo = maxsize
    for j in range(0, dimension[1]):
        if horizontalSeam[dimension[0]-1, j] < minimo:
            minimo = horizontalSeam[dimension[0]-1, j]
            horizontalSeamPath[dimension[0]-1, j] = 1
    for i in range(dimension[0]-2, 0, -1):
        for j in range(0, dimension[1]):
            if j == 0:
                if horizontalSeam[i, j] + min(horizontalSeam[i+1, j], horizontalSeam[i+1, j+1]) == minimo:
                    horizontalSeamPath[i, j] = 1
                    minimo = horizontalSeam[i, j]
            elif j == dimension[1]-1:
                if horizontalSeam[i, j] + min(horizontalSeam[i+1, j-1], horizontalSeam[i+1, j]) == minimo:
                    horizontalSeamPath[i, j] = 1
                    minimo = horizontalSeam[i, j]
            else:
                if horizontalSeam[i, j] + min(horizontalSeam[i+1, j-1], horizontalSeam[i+1, j], horizontalSeam[i+1, j+1]) == minimo:
                    horizontalSeamPath[i, j] = 1
                    minimo = horizontalSeam[i, j]
    return horizontalSeamPath

def removeVerticalSeam(imagen, dimension):
    verticalSeamPath = getVerticalSeamPath(imagen, dimension)
    for i in range(0, dimension[0]):
        for j in range(0, dimension[1]):
            if verticalSeamPath[i, j] == 1:
                for k in range(j, dimension[1]-1):
                    imagen[i, k] = imagen[i, k+1]
    return imagen

def removeHorizontalSeam(imagen, dimension):
    horizontalSeamPath = getHorizontalSeamPath(imagen)
    for j in range(0, dimension[1]):
        for i in range(0, dimension[0]):
            if horizontalSeamPath[i, j] == 1:
                for k in range(i, dimension[0]-1):
                    imagen[k, j] = imagen[k+1, j]
    return imagen

originalImage = cv2.imread("image.jpg")
dimension = originalImage.shape
print("ORIGINAL: Altura: {}, Anchura: {}".format(dimension[0], dimension[1]))
cv2.imshow("Original", originalImage)
cv2.waitKey(0)
cv2.destroyAllWindows()
for i in range(0, 5):
    modifiedImage = removeVerticalSeam(originalImage, dimension)
    dimension = modifiedImage.shape
    print("MODIFICADA: Altura: {}, Anchura: {}".format(dimension[0], dimension[1]))
cv2.imshow("ModifiedImage", modifiedImage)
cv2.waitKey(0)
cv2.destroyAllWindows()
"""
imagen = cv2.imread('image.jpg', cv2.IMREAD_UNCHANGED)
dimension = imagen.shape
print("Altura: {}, Anchura: {}".format(dimension[0], dimension[1]))

energyMatrix = energyMatrix(imagen)
energyImage = energyMatrix.astype(np.uint8)
print(energyMatrix)

cv2.imshow('Energy Image', energyImage)
cv2.imshow('Original Image', imagen)
cv2.waitKey(0)
cv2.destroyAllWindows()
"""